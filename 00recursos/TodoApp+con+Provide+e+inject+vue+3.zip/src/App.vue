<template>
  <div class="container mt-3">
    <tarea-app />
  </div>
</template>

<script>
import TareaApp from "./components/TareaApp.vue"

export default {
  components: { TareaApp },
  name: 'App',
}
</script>
