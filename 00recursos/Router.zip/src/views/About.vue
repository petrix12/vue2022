<template>
  <div class="about">
    <Titulo texto="Página de About" />
  </div>
</template>

<script>
import Titulo from '../components/Titulo'
export default {
  components:{
    Titulo
  }
}
</script>
