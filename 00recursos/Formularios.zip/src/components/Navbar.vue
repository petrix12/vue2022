<template>
  <div class="navbar navbar-dark bg-dark">
      <router-link to="/" class="navbar-brand">
          Formularios
      </router-link>
      <div class="d-flex">
          <router-link class="btn btn-dark" to="/">
            Tareas
          </router-link>
      </div>
  </div>
</template>

<script>
export default {

}
</script>

